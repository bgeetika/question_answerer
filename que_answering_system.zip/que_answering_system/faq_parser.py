from lxml import html
import urllib2
import re

class QABase(object):
    """interface to get questions and answers"""
    def get_qindices(self):
        raise NotImplementedError("get_qindices not implemented")

    def get_aindices(self):
        raise NotImplementedError("get_aindices not implemented")

    def get_q(self, index):
        raise NotImplementedError("get_q not implemented")

    def get_a(self, index):
        raise NotImplementedError("get_a not implemented")

    def get_a_for_q(self, q_index):
        raise NotImplementedError("get_a_for_q not implemented")


def get_qa(faq_url, q_a_xpaths):
    """given url and xpaths, it will return que_ans class instance """
    que_ans_list = __retrieve_text(faq_url, q_a_xpaths)
    que_ans = __dic_que_ans(que_ans_list)
    return QA(que_ans_list, que_ans)


class QA(QABase):
    """Implements QABase class and works with list and dictionary of questions and answers """
    def __init__(self, qa_list, qa_dict):
        super(QA, self).__init__()
        self.__qa_list = qa_list
        self.__qa_dict = qa_dict
        self.__a_set = set(qa_dict.values())

    def get_qindices(self):
        return self.__qa_dict.keys()

    def get_aindices(self):
        return self.__qa_dict.values()

    def get_q(self, index):
        if index in self.__qa_dict:
            return self.__qa_list[index]
        return None

    def get_a(self, index):
        if index in self.__a_set:
            return self.__qa_list[index]
        return None

    def get_a_for_q(self, q_index):
        if q_index in self.__qa_dict:
            return self.__qa_dict[q_index]
        return None


def __retrieve_text(faq_url, xpaths):
    """ Given faq_url and xpaths from the config file, gives their concatenated text.
    """
    def retrieve_text_impl(xml_tree, xpath):
        xpath_elements = xml_tree.xpath(xpath)
        texts = []
        for xpath_element in xpath_elements:
            text = ''.join([x for x in xpath_element.itertext()])
            text = re.sub(r'[^\x00-\x7F]+', ' ', text)
            texts.append(text)
        return texts

    content = urllib2.urlopen(faq_url).read()
    tree = html.fromstring(content)
    questions = []
    answers = []
    for i in xrange(0, len(xpaths), 2):
        questions.extend(retrieve_text_impl(tree, xpaths[i]))
        answers.extend(retrieve_text_impl(tree, xpaths[i+1]))

    q_a = []
    for i, question in enumerate(questions):
      q_a.append(question)
      q_a.append(answers[i])
    return q_a


def __dic_que_ans(que_ans_list):
    """This method will generate a dictionary for the question and their corresponding answers indices """
    que_ans = {}
    for i  in range(0, len(que_ans_list), 2):
        que_ans[i] = i+1
    '''for key , value in que_ans.iteritems():
        print que_ans_list[key] + " ------> "
        print  que_ans_list[value]
        print "\n\n\n"'''
    return que_ans
