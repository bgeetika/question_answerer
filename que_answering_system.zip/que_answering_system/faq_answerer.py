import glob
import os
import re
import string
import sys

def find_lxml_lib_dir(base_libs_dir):
    dirs = glob.glob(os.path.join(base_libs_dir, 'lxml-3.4.1/build/lib.*'))
    assert len(dirs) > 0, (dirs, base_libs_dir)
    return sorted([(d, os.path.getmtime(d)) for d in dirs],
                  key=lambda x: x[1],
                  reverse=True)[0][0]

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'libs'))
sys.path.insert(0, find_lxml_lib_dir(os.path.join(os.path.dirname(__file__), 'libs')))

import faq_parser
import mail_formatter
import tf_idf_scorer
import util


def __get_response(mail_number,
                   mail,
                   qa,
                   tfidf_scorer,
                   tfidf_score_lower_threshold):
    """ It will give the response given the mail using tfidf scores of all the
        questions computed using tfidf_scorer.
        If tfidf_score_lower_threshold is not None uses it to determine if the
        score implies a good match.
    """
    # Normalize the score by mail_norm so that a single threshold could be used
    # for all the emails.
    normalize_scores_by_mail_norm = tfidf_score_lower_threshold is not None
    scores, debug_info =  tfidf_scorer.compute_scores(
        mail, normalize_scores_by_mail_norm)
    max_qindices = sorted(scores.iteritems(), key=lambda x: x[1], reverse=True)
    mail = mail.lower().strip()
    #print 'mail=' + mail

    if not mail_formatter.MailFormatter.is_mail_addressed_to_prof_pollet(mail):
        return mail_formatter.MailFormatter.create_response(mail_number, 'SKIP\n')
    else:
        for qindex in max_qindices[0:1]:
          #print 'Question:\n  ' + qa.get_q(qindex[0])
          #print 'score: {0}'.format(qindex[1])
          #print 'mail_scores: {0}'.format(debug_info['mail'])
          #print 'word_scores: {0}'.format(debug_info['ques'][qindex[0]])
          #print 'length : {0}'.format(len(mail))
          if tfidf_score_lower_threshold and qindex[1] < tfidf_score_lower_threshold:
              return mail_formatter.MailFormatter.get_skip_response(mail_number)
          else:
              answer = qa.get_a(qa.get_a_for_q(qindex[0]))
              if len(answer) >= 2 and answer[:2] == 'A:':
                  answer = answer[2:]
              return mail_formatter.MailFormatter.get_mail_response(
                  mail_number, answer)
    return mail_formatter.MailFormatter.get_skip_response(mail_number)


def __get_arguments():
    """This method helps in parsing the command line arguments """
    if len(sys.argv) == 4:
        mail_file = sys.argv[1]
        faq_url = sys.argv[2]
        config_file = sys.argv[3]
        return mail_file, faq_url, config_file
    else:
        print "Usage {0} <mail_filepath> <faq_url> <faq_config_file>".format(
	    sys.argv[0])
        sys.exit()


def main():
    """This is the main function which will be calling subsequent functions."""
    mail_file, faq_url, config_file = __get_arguments()
    q_a_xpaths = [xpaths for xpaths in open(config_file).readlines() if xpaths]
    qa = faq_parser.get_qa(faq_url, q_a_xpaths)

    tfidf_scorer = tf_idf_scorer.TFIDFScorer(qa)
    for mail_number, mail in mail_formatter.MailFormatter.parse_mails(
        open(mail_file).read()):
        response = __get_response(mail_number, mail,
                                  qa, tfidf_scorer, None)
        assert response is not None, (
            'Error got Non response for mail {0}, {1}'.format(
                mail_number, mail))
        print response


if __name__ == '__main__':
    main()
